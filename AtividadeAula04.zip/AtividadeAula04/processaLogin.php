<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Dados Recebidos</title>
</head>
<body>
  <h1>Dados recebidos:</h1>

  <p><strong>E-mail:</strong> <?php echo $_POST["email"]; ?></p>
  <p><strong>Senha:</strong> <?php echo $_POST["senha"]; ?></p>
</body>
</html>
